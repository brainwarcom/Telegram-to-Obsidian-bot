import { Plugin } from 'obsidian';
import { CommandMapping } from '../types';
import { normalizePath } from '../utils/fileUtils';

const COMMANDS_FILE = '.obsidian/plugins/telegram-to-obsidian/commands.json';

/**
 * Управление командами (команда -> папка)
 */
export class CommandsManager {
	private plugin: Plugin;
	private commands: CommandMapping[] = [];

	constructor(plugin: Plugin) {
		this.plugin = plugin;
	}

	/**
	 * Загружает команды из файла
	 */
	async load(): Promise<void> {
		try {
			const dataDir = (this.plugin.app.vault.adapter as any).basePath;
			const commandsPath = `${dataDir}/${COMMANDS_FILE}`;
			
			const fs = require('fs');
			const path = require('path');
			
			if (fs.existsSync(commandsPath)) {
				const content = fs.readFileSync(commandsPath, 'utf-8');
				this.commands = JSON.parse(content);
				console.log(`CommandsManager: загружено ${this.commands.length} команд:`, this.commands);
			} else {
				console.log('CommandsManager: файл команд не найден, список команд пуст');
				this.commands = [];
			}
		} catch (error) {
			console.error('Error loading commands:', error);
			this.commands = [];
		}
	}

	/**
	 * Сохраняет команды в файл
	 */
	async save(): Promise<void> {
		try {
			const dataDir = (this.plugin.app.vault.adapter as any).basePath;
			const commandsPath = `${dataDir}/${COMMANDS_FILE}`;
			
			const fs = require('fs');
			const path = require('path');
			
			const dir = path.dirname(commandsPath);
			if (!fs.existsSync(dir)) {
				fs.mkdirSync(dir, { recursive: true });
			}
			
			fs.writeFileSync(commandsPath, JSON.stringify(this.commands, null, 2), 'utf-8');
		} catch (error) {
			console.error('Error saving commands:', error);
		}
	}

	/**
	 * Получает все команды
	 */
	getCommands(): CommandMapping[] {
		return [...this.commands];
	}

	/**
	 * Добавляет или обновляет команду
	 */
	async addCommand(command: string, folder: string): Promise<void> {
		const normalizedCommand = command.replace(/^\//, '').toLowerCase().trim();
		const normalizedFolder = normalizePath(folder.trim());
		
		const index = this.commands.findIndex(c => c.command === normalizedCommand);
		const mapping: CommandMapping = {
			command: normalizedCommand,
			folder: normalizedFolder,
		};
		
		if (index >= 0) {
			this.commands[index] = mapping;
			console.log(`CommandsManager: обновлена команда /${normalizedCommand} -> ${normalizedFolder}`);
		} else {
			this.commands.push(mapping);
			console.log(`CommandsManager: добавлена команда /${normalizedCommand} -> ${normalizedFolder}`);
		}
		
		await this.save();
		console.log(`CommandsManager: всего команд: ${this.commands.length}`);
	}

	/**
	 * Удаляет команду
	 */
	async removeCommand(command: string): Promise<void> {
		const normalizedCommand = command.replace(/^\//, '').toLowerCase().trim();
		this.commands = this.commands.filter(c => c.command !== normalizedCommand);
		await this.save();
	}

	/**
	 * Получает папку назначения для команды
	 */
	getFolderForCommand(command: string): string | null {
		const normalizedCommand = command.replace(/^\//, '').toLowerCase().trim();
		const mapping = this.commands.find(c => c.command === normalizedCommand);
		return mapping ? mapping.folder : null;
	}

	/**
	 * Находит команду в тексте сообщения
	 */
	findCommandInText(text: string): string | null {
		if (!text) return null;
		
		// Логируем доступные команды для отладки
		if (this.commands.length === 0) {
			console.log('CommandsManager: список команд пуст');
			return null;
		}
		
		console.log(`CommandsManager: поиск команды в тексте "${text}", доступно команд: ${this.commands.length}`);
		
		for (const cmd of this.commands) {
			// Ищем команду в начале строки или после пробела/начала строки
			// Паттерн: /команда в начале строки или после пробела, затем пробел или конец строки
			const pattern = new RegExp(`(^|\\s)/${cmd.command}(\\s|$)`, 'i');
			const matches = pattern.test(text);
			console.log(`CommandsManager: проверка команды /${cmd.command}, паттерн: ${pattern}, совпадение: ${matches}`);
			if (matches) {
				console.log(`CommandsManager: найдена команда /${cmd.command}`);
				return cmd.command;
			}
		}
		
		console.log('CommandsManager: команда не найдена');
		return null;
	}
}


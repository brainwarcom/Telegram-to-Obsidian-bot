import { QueuedMessage, TelegramMessage } from '../types';

const MESSAGE_QUEUE_FILE = '.obsidian/plugins/telegram-to-obsidian/messageQueue.json';
const LAST_SYNC_FILE = '.obsidian/plugins/telegram-to-obsidian/lastSync.json';

/**
 * Управление очередью сообщений
 */
export class MessageQueue {
	private basePath: string;
	private queue: QueuedMessage[] = [];
	private lastSyncTimestamp: number = 0;

	constructor(basePath: string) {
		this.basePath = basePath;
	}

	/**
	 * Загружает очередь из файла
	 */
	async load(): Promise<void> {
		try {
			const fs = require('fs');
			const path = require('path');
			const queuePath = `${this.basePath}/${MESSAGE_QUEUE_FILE}`;
			
			if (fs.existsSync(queuePath)) {
				const content = fs.readFileSync(queuePath, 'utf-8');
				this.queue = JSON.parse(content);
			}
		} catch (error) {
			console.error('Error loading message queue:', error);
			this.queue = [];
		}
	}

	/**
	 * Сохраняет очередь в файл
	 */
	async save(): Promise<void> {
		try {
			const fs = require('fs');
			const path = require('path');
			const queuePath = `${this.basePath}/${MESSAGE_QUEUE_FILE}`;
			const dir = path.dirname(queuePath);
			
			if (!fs.existsSync(dir)) {
				fs.mkdirSync(dir, { recursive: true });
			}
			
			fs.writeFileSync(queuePath, JSON.stringify(this.queue, null, 2), 'utf-8');
		} catch (error) {
			console.error('Error saving message queue:', error);
		}
	}

	/**
	 * Загружает время последней синхронизации
	 */
	async loadLastSync(): Promise<number> {
		try {
			const fs = require('fs');
			const path = require('path');
			const lastSyncPath = `${this.basePath}/${LAST_SYNC_FILE}`;
			
			if (fs.existsSync(lastSyncPath)) {
				const content = fs.readFileSync(lastSyncPath, 'utf-8');
				const data = JSON.parse(content);
				this.lastSyncTimestamp = data.timestamp || 0;
			}
		} catch (error) {
			console.error('Error loading last sync timestamp:', error);
			this.lastSyncTimestamp = 0;
		}
		
		return this.lastSyncTimestamp;
	}

	/**
	 * Сохраняет время последней синхронизации
	 */
	async saveLastSync(timestamp: number): Promise<void> {
		try {
			const fs = require('fs');
			const path = require('path');
			const lastSyncPath = `${this.basePath}/${LAST_SYNC_FILE}`;
			const dir = path.dirname(lastSyncPath);
			
			if (!fs.existsSync(dir)) {
				fs.mkdirSync(dir, { recursive: true });
			}
			
			fs.writeFileSync(lastSyncPath, JSON.stringify({ timestamp }, null, 2), 'utf-8');
			this.lastSyncTimestamp = timestamp;
		} catch (error) {
			console.error('Error saving last sync timestamp:', error);
		}
	}

	/**
	 * Добавляет сообщение в очередь
	 */
	async addMessage(message: TelegramMessage): Promise<void> {
		const queuedMessage: QueuedMessage = {
			message,
			processed: false,
			queuedAt: Date.now(),
		};
		
		// Проверяем, нет ли уже этого сообщения в очереди
		const exists = this.queue.some(
			qm => qm.message.message_id === message.message_id && qm.message.chat.id === message.chat.id
		);
		
		if (!exists) {
			this.queue.push(queuedMessage);
			await this.save();
		}
	}

	/**
	 * Получает необработанные сообщения
	 */
	getUnprocessedMessages(): QueuedMessage[] {
		return this.queue.filter(qm => !qm.processed);
	}

	/**
	 * Получает все сообщения
	 */
	getAllMessages(): QueuedMessage[] {
		return [...this.queue];
	}

	/**
	 * Помечает сообщение как обработанное
	 */
	async markAsProcessed(messageId: number, chatId: number): Promise<void> {
		const queuedMessage = this.queue.find(
			qm => qm.message.message_id === messageId && qm.message.chat.id === chatId
		);
		
		if (queuedMessage) {
			queuedMessage.processed = true;
			await this.save();
		}
	}

	/**
	 * Очищает обработанные сообщения
	 */
	async clearProcessed(): Promise<void> {
		this.queue = this.queue.filter(qm => !qm.processed);
		await this.save();
	}

	/**
	 * Получает время последней синхронизации
	 */
	getLastSyncTimestamp(): number {
		return this.lastSyncTimestamp;
	}

	/**
	 * Проверяет, обработано ли сообщение
	 */
	isProcessed(messageId: number, chatId: number): boolean {
		const queuedMessage = this.queue.find(
			qm => qm.message.message_id === messageId && qm.message.chat.id === chatId
		);
		return queuedMessage ? queuedMessage.processed : false;
	}

	/**
	 * Получает сообщение по ID (даже если оно обработано)
	 */
	getMessage(messageId: number, chatId: number): QueuedMessage | null {
		return this.queue.find(
			qm => qm.message.message_id === messageId && qm.message.chat.id === chatId
		) || null;
	}
}


/**
 * Утилиты для работы с файлами
 */

/**
 * Создает путь, заменяя недопустимые символы
 */
export function sanitizePath(path: string): string {
	return path.replace(/[<>:"|?*\x00-\x1f]/g, '_').replace(/\.\./g, '_');
}

/**
 * Нормализует путь, убирая лишние слеши
 */
export function normalizePath(path: string): string {
	return path.replace(/\/+/g, '/').replace(/^\/+/, '').replace(/\/+$/, '');
}

/**
 * Объединяет части пути
 */
export function joinPath(...parts: string[]): string {
	return normalizePath(parts.filter(p => p).join('/'));
}


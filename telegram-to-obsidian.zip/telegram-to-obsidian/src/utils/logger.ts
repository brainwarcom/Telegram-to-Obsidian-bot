import { Plugin } from 'obsidian';
import { formatDateForNote } from './dateUtils';

const LOGS_FILE = 'Telegram_Logs.md';

export enum LogLevel {
	INFO = 'INFO',
	WARN = 'WARN',
	ERROR = 'ERROR',
	DEBUG = 'DEBUG',
}

export interface LogEntry {
	timestamp: number;
	level: LogLevel;
	message: string;
	data?: any;
}

/**
 * Система логирования для плагина
 */
export class Logger {
	private plugin: Plugin;
	private basePath: string;
	private logs: LogEntry[] = [];
	private maxLogs: number = 1000; // Максимальное количество записей в памяти
	private defaultFolder: string = 'tto'; // Дефолтная папка для логов

	constructor(plugin: Plugin) {
		this.plugin = plugin;
		this.basePath = (plugin.app.vault.adapter as any).basePath;
		
		// Получаем дефолтную папку из настроек
		const settings = (plugin as any).settings;
		if (settings?.defaultFolder) {
			this.defaultFolder = settings.defaultFolder;
		}
	}

	/**
	 * Устанавливает дефолтную папку для логов
	 */
	setDefaultFolder(folder: string): void {
		this.defaultFolder = folder || 'tto';
	}

	/**
	 * Добавляет запись в лог
	 */
	log(level: LogLevel, message: string, data?: any): void {
		const entry: LogEntry = {
			timestamp: Date.now(),
			level,
			message,
			data,
		};

		this.logs.push(entry);

		// Ограничиваем количество логов в памяти
		if (this.logs.length > this.maxLogs) {
			this.logs.shift();
		}

		// Также пишем в консоль
		const timestamp = formatDateForNote(new Date(entry.timestamp));
		const logMessage = `[${timestamp}] [${level}] ${message}`;
		
		if (data) {
			console.log(logMessage, data);
		} else {
			console.log(logMessage);
		}
	}

	/**
	 * Логирование уровня INFO
	 */
	info(message: string, data?: any): void {
		this.log(LogLevel.INFO, message, data);
	}

	/**
	 * Логирование уровня WARN
	 */
	warn(message: string, data?: any): void {
		this.log(LogLevel.WARN, message, data);
	}

	/**
	 * Логирование уровня ERROR
	 */
	error(message: string, data?: any): void {
		this.log(LogLevel.ERROR, message, data);
	}

	/**
	 * Логирование уровня DEBUG
	 */
	debug(message: string, data?: any): void {
		this.log(LogLevel.DEBUG, message, data);
	}

	/**
	 * Сохраняет логи в файл заметки в корне хранилища
	 */
	async saveToFile(): Promise<string> {
		// Создаем Markdown содержимое
		let content = '# Логи Telegram to Obsidian\n\n';
		content += `**Последнее обновление:** ${formatDateForNote(new Date())}\n\n`;
		content += '---\n\n';

		// Сортируем логи по времени (новые первыми)
		const sortedLogs = [...this.logs].sort((a, b) => b.timestamp - a.timestamp);

		for (const entry of sortedLogs) {
			const timestamp = formatDateForNote(new Date(entry.timestamp));
			const levelEmoji = this.getLevelEmoji(entry.level);
			
			content += `## ${levelEmoji} [${timestamp}] ${entry.level}\n\n`;
			content += `${entry.message}\n\n`;
			
			if (entry.data) {
				content += '```json\n';
				try {
					content += JSON.stringify(entry.data, null, 2);
				} catch (e) {
					content += String(entry.data);
				}
				content += '\n```\n\n';
			}
			
			content += '---\n\n';
		}

		// Сохраняем в хранилище Obsidian в корне дефолтной папки
		try {
			// Нормализуем путь к дефолтной папке
			const normalizedFolder = this.defaultFolder ? this.defaultFolder.replace(/\\/g, '/').replace(/\/+/g, '/') : '';
			
			// Создаем путь к файлу логов в корне дефолтной папки
			const logsPath = normalizedFolder ? `${normalizedFolder}/${LOGS_FILE}` : LOGS_FILE;
			
			// Создаем папку, если её нет (создаем все подпапки)
			if (normalizedFolder) {
				const folders = normalizedFolder.split('/').filter(f => f);
				let currentPath = '';
				for (const folder of folders) {
					currentPath = currentPath ? `${currentPath}/${folder}` : folder;
					const sanitizedPath = currentPath.replace(/[<>:"|?*\x00-\x1f]/g, '_').replace(/\.\./g, '_');
					if (!this.plugin.app.vault.getAbstractFileByPath(sanitizedPath)) {
						await this.plugin.app.vault.createFolder(sanitizedPath);
					}
				}
			}
			
			const sanitizedLogsPath = logsPath.replace(/[<>:"|?*\x00-\x1f]/g, '_').replace(/\.\./g, '_');
			const existingFile = this.plugin.app.vault.getAbstractFileByPath(sanitizedLogsPath);
			
			if (existingFile) {
				await this.plugin.app.vault.modify(existingFile as any, content);
			} else {
				await this.plugin.app.vault.create(sanitizedLogsPath, content);
			}
			
			return sanitizedLogsPath;
		} catch (error) {
			console.error('Error saving logs to vault:', error);
			throw error;
		}
	}

	/**
	 * Открывает заметку с логами
	 */
	async openLogsNote(): Promise<void> {
		try {
			const logsPath = await this.saveToFile();
			const file = this.plugin.app.vault.getAbstractFileByPath(logsPath);
			if (file) {
				const leaf = this.plugin.app.workspace.getLeaf(true);
				await leaf.openFile(file as any);
			}
		} catch (error) {
			console.error('Error opening logs note:', error);
		}
	}

	/**
	 * Получает эмодзи для уровня лога
	 */
	private getLevelEmoji(level: LogLevel): string {
		switch (level) {
			case LogLevel.INFO:
				return 'ℹ️';
			case LogLevel.WARN:
				return '⚠️';
			case LogLevel.ERROR:
				return '❌';
			case LogLevel.DEBUG:
				return '🔍';
			default:
				return '📝';
		}
	}

	/**
	 * Получает все логи
	 */
	getLogs(): LogEntry[] {
		return [...this.logs];
	}

	/**
	 * Очищает логи
	 */
	clear(): void {
		this.logs = [];
	}
}


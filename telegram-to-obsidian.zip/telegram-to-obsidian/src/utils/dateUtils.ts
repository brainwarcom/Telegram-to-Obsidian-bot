/**
 * Утилиты для работы с датами
 */

/**
 * Форматирует дату в формат YYYY-MM-DD
 */
export function formatDate(date: Date): string {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	return `${year}-${month}-${day}`;
}

/**
 * Форматирует дату для отображения в заметке
 */
export function formatDateForNote(date: Date): string {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');
	return `${year}-${month}-${day} ${hours}:${minutes}`;
}

/**
 * Форматирует дату для пути папки (YYYY/MM/DD)
 */
export function formatDateForPath(date: Date): string {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	return `${year}/${month}/${day}`;
}

/**
 * Преобразует Unix timestamp в Date
 */
export function timestampToDate(timestamp: number): Date {
	return new Date(timestamp * 1000);
}


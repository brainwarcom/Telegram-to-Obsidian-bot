import { Plugin } from 'obsidian';
import { PluginSettings } from './types';
import { TelegramBotManager } from './bot/bot';
import { MessageQueue } from './storage/messageQueue';
import { CommandsManager } from './storage/commands';
import { SyncService } from './sync/syncService';
import { SyncButton } from './ui/syncButton';
import { RibbonSyncButton } from './ui/ribbonButton';
import { TelegramToObsidianSettingTab } from './ui/settingsTab';
import { Logger } from './utils/logger';

const DEFAULT_SETTINGS: PluginSettings = {
	token: '',
	commands: [],
	lastSyncTimestamp: 0,
	defaultFolder: 'tto',
};

/**
 * Главный класс плагина Telegram to Obsidian
 */
export default class TelegramToObsidianPlugin extends Plugin {
	settings: PluginSettings;
	botManager: TelegramBotManager | null = null;
	messageQueue: MessageQueue | null = null;
	commandsManager: CommandsManager | null = null;
	syncService: SyncService | null = null;
	syncButton: SyncButton | null = null;
	ribbonSyncButton: RibbonSyncButton | null = null;
	logger: Logger | null = null;

	async onload() {
		console.log('Loading Telegram to Obsidian plugin');

		// Загружаем настройки (до инициализации logger, чтобы он мог получить defaultFolder)
		await this.loadSettings();

		// Инициализируем логгер
		this.logger = new Logger(this);
		this.logger.info('Плагин Telegram to Obsidian загружается');

		// Инициализируем компоненты
		const basePath = (this.app.vault.adapter as any).basePath;
		
		this.messageQueue = new MessageQueue(basePath);
		await this.messageQueue.load();
		await this.messageQueue.loadLastSync();

		this.commandsManager = new CommandsManager(this);
		await this.commandsManager.load();

		this.syncService = new SyncService(
			this,
			this.messageQueue,
			this.commandsManager,
			this.settings.token,
			this.logger
		);

		this.botManager = new TelegramBotManager(this, this.messageQueue, this.logger);

		// Устанавливаем botManager в syncService для отправки реакций
		if (this.syncService && this.botManager) {
			this.syncService.setBotManager(this.botManager);
			// Устанавливаем syncService в botManager для автоматической синхронизации
			this.botManager.setSyncService(this.syncService);
			// Устанавливаем commandsManager в botManager для команды /help
			this.botManager.setCommandsManager(this.commandsManager);
		}

		// Кнопка в статус-баре
		this.syncButton = new SyncButton(this, this.syncService);
		this.syncButton.addToStatusBar();

		// Кнопки в ribbon (вертикальная панель)
		this.ribbonSyncButton = new RibbonSyncButton(this, this.syncService, this.logger);
		this.ribbonSyncButton.addToRibbon();
		this.ribbonSyncButton.addLogsButtonToRibbon();

		// Добавляем вкладку настроек
		this.addSettingTab(new TelegramToObsidianSettingTab(this.app, this));

		// Запускаем бота, если токен установлен
		if (this.settings.token) {
			try {
				await this.botManager.start(this.settings.token);
				this.logger?.info('Telegram бот запущен');
				console.log('Telegram bot started');
			} catch (error) {
				this.logger?.error('Не удалось запустить Telegram бота', error);
				console.error('Failed to start Telegram bot:', error);
			}
		}

		// Выполняем автоматическую синхронизацию при запуске
		if (this.syncService) {
			try {
				this.logger?.info('Запуск автоматической синхронизации при старте');
				const result = await this.syncService.sync();
				this.logger?.info(`Автосинхронизация завершена: ${result.processed} обработано, ${result.errors} ошибок`);
				console.log(`Initial sync completed: ${result.processed} processed, ${result.errors} errors`);
			} catch (error) {
				this.logger?.error('Ошибка автосинхронизации', error);
				console.error('Initial sync error:', error);
			}
		}
	}

	async onunload() {
		this.logger?.info('Плагин Telegram to Obsidian выгружается');
		console.log('Unloading Telegram to Obsidian plugin');

		// Останавливаем бота
		if (this.botManager) {
			await this.botManager.stop();
		}

		// Удаляем кнопку синхронизации из статус-бара
		if (this.syncButton) {
			this.syncButton.removeFromStatusBar();
		}

		// Удаляем кнопки из ribbon
		if (this.ribbonSyncButton) {
			this.ribbonSyncButton.removeFromRibbon();
		}
	}

	async loadSettings() {
		this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
	}

	async saveSettings() {
		await this.saveData(this.settings);
	}

	/**
	 * Перезапускает бота
	 */
	async restartBot(): Promise<void> {
		if (this.botManager) {
			this.logger?.info('Перезапуск Telegram бота');
			await this.botManager.stop();
			if (this.settings.token) {
				await this.botManager.start(this.settings.token);
				if (this.syncService) {
					this.syncService.updateBotToken(this.settings.token);
					this.syncService.setBotManager(this.botManager);
					// Устанавливаем syncService в botManager для автоматической синхронизации
					this.botManager.setSyncService(this.syncService);
					// Устанавливаем commandsManager в botManager для команды /help
					if (this.commandsManager) {
						this.botManager.setCommandsManager(this.commandsManager);
					}
				}
			}
		}
	}

	/**
	 * Останавливает бота
	 */
	async stopBot(): Promise<void> {
		if (this.botManager) {
			await this.botManager.stop();
		}
	}

	/**
	 * Получает информацию о боте
	 */
	async getBotInfo(): Promise<any> {
		if (this.botManager) {
			return await this.botManager.getBotInfo();
		}
		return null;
	}
}


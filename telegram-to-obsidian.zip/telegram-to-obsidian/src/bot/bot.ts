import TelegramBot from 'node-telegram-bot-api';
import { Plugin } from 'obsidian';
import { MessageQueue } from '../storage/messageQueue';
import { TelegramMessage } from '../types';
import { Logger } from '../utils/logger';

/**
 * Управление Telegram ботом
 */
export class TelegramBotManager {
	private plugin: Plugin;
	private bot: TelegramBot | null = null;
	private messageQueue: MessageQueue;
	private logger: Logger;
	private syncService: any = null;
	private commandsManager: any = null;
	private isRunning: boolean = false;
	private isRestartingPolling: boolean = false; // Флаг для предотвращения множественных перезапусков

	constructor(plugin: Plugin, messageQueue: MessageQueue, logger: Logger) {
		this.plugin = plugin;
		this.messageQueue = messageQueue;
		this.logger = logger;
	}

	/**
	 * Устанавливает ссылку на syncService для автоматической синхронизации
	 */
	setSyncService(syncService: any): void {
		this.syncService = syncService;
	}

	/**
	 * Устанавливает ссылку на commandsManager для команды /help
	 */
	setCommandsManager(commandsManager: any): void {
		this.commandsManager = commandsManager;
	}

	/**
	 * Инициализирует и запускает бота
	 */
	async start(token: string): Promise<void> {
		if (this.isRunning && this.bot) {
			this.logger.info('Бот уже запущен, останавливаем...');
			await this.stop();
			// Дополнительная задержка для гарантированного освобождения соединения
			await new Promise(resolve => setTimeout(resolve, 1000));
		}

		if (!token || token.trim() === '') {
			this.logger.error('Токен бота не указан');
			throw new Error('Telegram bot token is required');
		}

		this.logger.info('Инициализация Telegram бота...', { token_length: token.length });

		try {
			// Создаем временный бот для очистки предыдущих подключений
			const tempBot = new TelegramBot(token, { polling: false });
			
			try {
				// Сбрасываем webhook (если был настроен)
				this.logger.info('🧹 Сброс webhook...');
				await tempBot.deleteWebHook();
				this.logger.info('✅ Webhook сброшен');
			} catch (error: any) {
				this.logger.warn('⚠️ Не удалось сбросить webhook (возможно, его не было)', error);
			} finally {
				// Закрываем временный бот
				try {
					tempBot.removeAllListeners();
				} catch (error) {
					// Игнорируем ошибки при очистке
				}
			}

			// Даем время Telegram API обработать сброс
			await new Promise(resolve => setTimeout(resolve, 1000));

			this.bot = new TelegramBot(token, { 
				polling: {
					interval: 300,
					autoStart: true,
					params: {
						timeout: 10
					}
				}
			});
			this.isRunning = true;

			// Проверяем подключение и получаем информацию о боте
			try {
				const botInfo = await this.bot.getMe();
				this.logger.info('✅ Бот успешно подключен к Telegram API', {
					bot_id: botInfo.id,
					username: botInfo.username,
					first_name: botInfo.first_name,
					can_join_groups: (botInfo as any).can_join_groups,
					can_read_all_group_messages: (botInfo as any).can_read_all_group_messages,
				});
			} catch (error: any) {
				this.logger.error('❌ Не удалось подключиться к Telegram API', error);
				throw error;
			}

			// Логируем старт polling
			this.logger.info('🔄 Polling запущен, ожидание сообщений...');

			// Обработчик команды /help
			this.bot.onText(/\/help/i, async (msg: TelegramMessage) => {
				try {
					const chatId = msg.chat.id;
					
					// Получаем commandsManager и настройки из плагина
					const plugin = this.plugin as any;
					const commandsManager = this.commandsManager || plugin.commandsManager;
					
					if (!commandsManager) {
						await this.bot?.sendMessage(chatId, '❌ Ошибка: менеджер команд не инициализирован');
						return;
					}
					
					const commands = commandsManager.getCommands();
					const defaultFolder = plugin.settings?.defaultFolder || 'tto';
					
					let helpText = '📋 *Список зарегистрированных команд:*\n\n';
					
					if (commands.length === 0) {
						helpText += 'Команды не настроены.\n\n';
					} else {
						for (const cmd of commands) {
							helpText += `\`/${cmd.command}\` → \`${cmd.folder}\`\n`;
						}
						helpText += '\n';
					}
					
					helpText += `📁 *Папка по умолчанию:* \`${defaultFolder}\`\n\n`;
					helpText += '💡 *Как использовать:*\n';
					helpText += 'Отправьте сообщение с командой (например: `/test текст`), и оно будет сохранено в указанную папку.';
					
					await this.bot?.sendMessage(chatId, helpText, { parse_mode: 'Markdown' });
					this.logger.info(`Отправлен ответ на команду /help в чат ${chatId}`);
				} catch (error) {
					this.logger.error('Ошибка при обработке команды /help', error);
				}
			});

			// Обработчик всех сообщений
			this.bot.on('message', async (msg: TelegramMessage) => {
				try {
					// Пропускаем команду /help - она обрабатывается отдельным обработчиком
					if (msg.text && /^\/help\s*$/i.test(msg.text.trim())) {
						return;
					}

					this.logger.info('📨 Получено сообщение от Telegram', {
						message_id: msg.message_id,
						chat_id: msg.chat.id,
						chat_type: (msg.chat as any).type || 'unknown',
						from_username: msg.from?.username,
						from_id: msg.from?.id,
						has_text: !!msg.text,
						has_photo: !!msg.photo,
						has_video: !!msg.video,
						has_document: !!msg.document,
						text_preview: msg.text ? msg.text.substring(0, 50) : null,
					});

					// Добавляем реакцию "синхронизируется"
					// Проверяем, что это не сообщение от самого бота
					const botInfo = await this.getBotInfo();
					const isBotMessage = botInfo && msg.from && msg.from.id === botInfo.id;
					
					if (!isBotMessage && this.bot) {
						// Проверяем наличие метода setMessageReaction
						if (typeof this.bot.setMessageReaction === 'function') {
							try {
								const chatId = msg.chat.id;
								const messageId = msg.message_id;
								
								this.logger.debug(`Попытка установить реакцию 👀 на сообщение ${messageId} в чате ${chatId}`);
								
								await this.bot.setMessageReaction(
									chatId, 
									messageId, 
									{ reaction: [{ type: 'emoji', emoji: '👀' as any }] }
								);
								this.logger.info(`✅ Реакция 👀 успешно установлена на сообщение ${messageId}`);
							} catch (error: any) {
								const errorMsg = error?.message || String(error);
								const errorCode = error?.response?.body?.error_code || 'unknown';
								// Не логируем ошибку, если метод не поддерживается
								if (!errorMsg.includes('is not a function')) {
									this.logger.error(`❌ Не удалось установить реакцию 👀 на сообщение ${msg.message_id}: ${errorMsg} (код: ${errorCode})`, {
										error: error,
										chat_id: msg.chat.id,
										message_id: msg.message_id,
										chat_type: msg.chat.id < 0 ? 'group' : 'private',
										from_id: msg.from?.id,
										bot_id: botInfo?.id,
									});
								}
							}
						} else {
							this.logger.debug('Метод setMessageReaction недоступен в данной версии библиотеки');
						}
					} else if (isBotMessage) {
						this.logger.debug('Пропущена установка реакции на собственное сообщение бота');
					}

					// Добавляем сообщение в очередь для обработки плагином
					await this.messageQueue.addMessage(msg);
					
					// Запускаем автоматическую синхронизацию через небольшой таймаут
					// чтобы дать время другим сообщениям накопиться
					if (this.syncService) {
						setTimeout(async () => {
							try {
								this.logger.info('Автоматическая синхронизация при получении нового сообщения');
								const result = await this.syncService.sync();
								this.logger.info(`Автосинхронизация завершена: ${result.processed} обработано, ${result.errors} ошибок`);
							} catch (error) {
								this.logger.error('Ошибка при автосинхронизации', error);
							}
						}, 2000); // 2 секунды задержка
					}
				} catch (error) {
					this.logger.error('Ошибка при обработке сообщения', error);
				}
			});

			// Обработчик ошибок
			this.bot.on('error', (error: any) => {
				this.logger.error('❌ Ошибка Telegram бота', {
					message: error?.message || String(error),
					code: error?.code,
					response: error?.response?.body,
					stack: error?.stack,
				});
				console.error('Telegram bot error:', error);
			});

			// Обработчик polling_error
			this.bot.on('polling_error', async (error: any) => {
				const errorCode = error?.response?.body?.error_code;
				const errorMessage = error?.message || String(error);
				
				this.logger.error('❌ Ошибка polling Telegram бота', {
					message: errorMessage,
					code: error?.code,
					error_code: errorCode,
					response: error?.response?.body,
					stack: error?.stack,
				});
				console.error('Telegram bot polling error:', error);

				// Если ошибка 409 Conflict, останавливаем polling и пытаемся перезапустить
				// Но только если мы еще не перезапускаем
				if ((errorCode === 409 || errorMessage.includes('409 Conflict')) && !this.isRestartingPolling) {
					this.isRestartingPolling = true;
					this.logger.warn('⚠️ Обнаружена ошибка 409 Conflict, останавливаем polling...');
					try {
						// Останавливаем polling
						if (this.bot && this.bot.isPolling()) {
							await this.bot.stopPolling();
							this.logger.info('✅ Polling остановлен');
						}
						// Ждем освобождения соединения
						await new Promise(resolve => setTimeout(resolve, 5000));
						// Перезапускаем polling
						if (this.bot && !this.bot.isPolling()) {
							await this.bot.startPolling();
							this.logger.info('✅ Polling перезапущен после ошибки 409');
						}
					} catch (restartError) {
						this.logger.error('❌ Не удалось перезапустить polling после ошибки 409', restartError);
					} finally {
						// Сбрасываем флаг через некоторое время
						setTimeout(() => {
							this.isRestartingPolling = false;
						}, 10000);
					}
				}
			});

			// Обработчик успешного polling
			this.bot.on('polling', () => {
				this.logger.debug('🔄 Polling активен');
			});

			// Проверка работоспособности бота (без getUpdates, чтобы не конфликтовать с polling)
			setTimeout(async () => {
				try {
					const botInfo = await this.bot?.getMe();
					this.logger.info('🔍 Проверка бота: подключение активно', {
						bot_id: botInfo?.id,
						username: botInfo?.username,
						isPolling: this.bot?.isPolling()
					});
				} catch (error: any) {
					this.logger.error('❌ Проверка бота: ошибка подключения', error);
				}
			}, 2000);

			this.logger.info('✅ Telegram бот успешно запущен и готов к приему сообщений');
			console.log('Telegram bot started successfully');
		} catch (error: any) {
			this.logger.error('❌ Критическая ошибка при запуске бота', {
				error_message: error?.message || String(error),
				error_code: error?.code,
				error_response: error?.response?.body,
			});
			console.error('Error starting Telegram bot:', error);
			this.isRunning = false;
			throw error;
		}
	}

	/**
	 * Останавливает бота
	 */
	async stop(): Promise<void> {
		if (this.bot && this.isRunning) {
			try {
				this.logger.info('Остановка Telegram бота...');
				
				// Останавливаем polling
				if (this.bot.isPolling()) {
					await this.bot.stopPolling();
					// Даем время Telegram API освободить соединение
					await new Promise(resolve => setTimeout(resolve, 500));
				}
				
				// Удаляем все обработчики событий
				this.bot.removeAllListeners();
				
				this.bot = null;
				this.isRunning = false;
				this.logger.info('✅ Telegram бот остановлен');
				console.log('Telegram bot stopped');
			} catch (error: any) {
				this.logger.error('Ошибка при остановке бота', error);
				console.error('Error stopping Telegram bot:', error);
				// В любом случае очищаем состояние
				this.bot = null;
				this.isRunning = false;
			}
		} else if (this.bot) {
			// Если бот есть, но isRunning = false, все равно очищаем
			try {
				if (this.bot.isPolling()) {
					await this.bot.stopPolling();
				}
				this.bot.removeAllListeners();
			} catch (error) {
				// Игнорируем ошибки при очистке
			}
			this.bot = null;
		}
	}

	/**
	 * Проверяет, запущен ли бот
	 */
	isBotRunning(): boolean {
		return this.isRunning && this.bot !== null;
	}

	/**
	 * Получает статус бота для диагностики
	 */
	async getDiagnosticInfo(): Promise<any> {
		if (!this.bot) {
			return {
				status: 'stopped',
				isRunning: this.isRunning,
			};
		}

		try {
			const botInfo = await this.bot.getMe();
			return {
				status: 'running',
				isRunning: this.isRunning,
				isPolling: this.bot.isPolling(),
				botInfo: {
					id: botInfo.id,
					username: botInfo.username,
					first_name: botInfo.first_name,
				},
			};
		} catch (error) {
			return {
				status: 'error',
				isRunning: this.isRunning,
				isPolling: this.bot.isPolling(),
				error: error,
			};
		}
	}

	/**
	 * Получает информацию о боте
	 */
	async getBotInfo(): Promise<any> {
		if (!this.bot) {
			this.logger.debug('getBotInfo: бот не инициализирован (this.bot === null)');
			return null;
		}

		if (!this.isRunning) {
			this.logger.debug('getBotInfo: бот не запущен (isRunning === false)');
			return null;
		}

		try {
			const botInfo = await this.bot.getMe();
			this.logger.debug('getBotInfo: информация получена успешно', {
				bot_id: botInfo?.id,
				username: botInfo?.username
			});
			return botInfo;
		} catch (error: any) {
			const errorMsg = error?.message || String(error);
			const errorCode = error?.code || 'unknown';
			this.logger.error('Ошибка при получении информации о боте', {
				error: errorMsg,
				code: errorCode,
				response: error?.response?.body,
				isPolling: this.bot?.isPolling(),
				isRunning: this.isRunning
			});
			console.error('Error getting bot info:', error);
			return null;
		}
	}

	/**
	 * Сбрасывает webhook и очищает предыдущие подключения
	 */
	async resetWebhook(token: string): Promise<void> {
		const tempBot = new TelegramBot(token, { polling: false });
		try {
			this.logger.info('🧹 Ручной сброс webhook...');
			await tempBot.deleteWebHook();
			this.logger.info('✅ Webhook успешно сброшен');
		} catch (error: any) {
			this.logger.error('❌ Ошибка при сбросе webhook', error);
			throw error;
		} finally {
			// Закрываем временный бот
			try {
				tempBot.removeAllListeners();
			} catch (error) {
				// Игнорируем ошибки при очистке
			}
		}
	}

	/**
	 * Устанавливает реакцию на сообщение
	 */
	async setReaction(chatId: number, messageId: number, emoji: string): Promise<void> {
		if (!this.bot) {
			this.logger.warn('Бот не инициализирован, невозможно установить реакцию');
			return;
		}

		try {
			// Пробуем использовать метод setMessageReaction, если доступен
			if (typeof this.bot.setMessageReaction === 'function') {
				await this.bot.setMessageReaction(chatId, messageId, { 
					reaction: [{ type: 'emoji', emoji: emoji as any }] 
				});
				this.logger.debug(`Реакция ${emoji} установлена на сообщение ${messageId}`);
				return;
			}

			// Если метод недоступен, пробуем использовать прямой вызов API
			if ((this.bot as any).telegram && typeof ((this.bot as any).telegram as any).callApi === 'function') {
				await ((this.bot as any).telegram as any).callApi('setMessageReaction', {
					chat_id: chatId,
					message_id: messageId,
					reaction: [{ type: 'emoji', emoji: emoji }]
				});
				this.logger.debug(`Реакция ${emoji} установлена на сообщение ${messageId} через callApi`);
				return;
			}

			// Если и это не работает, пробуем через request
			if ((this.bot as any).telegram && typeof ((this.bot as any).telegram as any).request === 'function') {
				await ((this.bot as any).telegram as any).request('setMessageReaction', {
					chat_id: chatId,
					message_id: messageId,
					reaction: [{ type: 'emoji', emoji: emoji }]
				});
				this.logger.debug(`Реакция ${emoji} установлена на сообщение ${messageId} через request`);
				return;
			}

			this.logger.debug(`Метод setMessageReaction недоступен, пропускаем установку реакции ${emoji}`);
		} catch (error: any) {
			const errorMsg = error?.message || String(error);
			// Не логируем ошибку, если метод не поддерживается
			if (!errorMsg.includes('is not a function') && !errorMsg.includes('not supported')) {
				this.logger.warn(`Не удалось установить реакцию ${emoji} на сообщение ${messageId}: ${errorMsg}`, error);
			}
		}
	}
}


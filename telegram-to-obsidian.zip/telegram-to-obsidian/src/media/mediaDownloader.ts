import { Plugin } from 'obsidian';
import { TelegramMessage, MediaFile } from '../types';
import { sanitizePath, joinPath } from '../utils/fileUtils';

/**
 * Модуль для скачивания медиафайлов из Telegram
 */
export class MediaDownloader {
	private plugin: Plugin;
	private basePath: string;
	private botToken: string;

	constructor(plugin: Plugin, botToken: string) {
		this.plugin = plugin;
		this.botToken = botToken;
		this.basePath = (plugin.app.vault.adapter as any).basePath;
	}

	/**
	 * Скачивает медиафайл из Telegram
	 */
	private async downloadFile(fileId: string, filePath: string): Promise<void> {
		const https = require('https');
		const fs = require('fs');
		const path = require('path');

		return new Promise((resolve, reject) => {
			// Сначала получаем путь к файлу через Telegram API
			const getFileUrl = `https://api.telegram.org/bot${this.botToken}/getFile?file_id=${fileId}`;

			https.get(getFileUrl, (res: any) => {
				let data = '';
				res.on('data', (chunk: any) => {
					data += chunk;
				});
				res.on('end', () => {
					try {
						const response = JSON.parse(data);
						if (response.ok && response.result) {
							const filePathTelegram = response.result.file_path;
							const downloadUrl = `https://api.telegram.org/file/bot${this.botToken}/${filePathTelegram}`;

							// Создаем директорию, если её нет
							const dir = path.dirname(filePath);
							if (!fs.existsSync(dir)) {
								fs.mkdirSync(dir, { recursive: true });
							}

							// Скачиваем файл
							const file = fs.createWriteStream(filePath);
							https.get(downloadUrl, (downloadRes: any) => {
								downloadRes.pipe(file);
								file.on('finish', () => {
									file.close();
									resolve();
								});
							}).on('error', (err: any) => {
								fs.unlinkSync(filePath);
								reject(err);
							});
						} else {
							reject(new Error('Failed to get file path from Telegram'));
						}
					} catch (error) {
						reject(error);
					}
				});
			}).on('error', reject);
		});
	}

	/**
	 * Обрабатывает медиа из сообщения
	 * @param message - Сообщение Telegram
	 * @param baseFolder - Базовая папка для сохранения медиа (например, "пример" или "work/notes")
	 */
	async processMedia(message: TelegramMessage, baseFolder: string): Promise<MediaFile[]> {
		const mediaFiles: MediaFile[] = [];
		const fs = require('fs');
		const path = require('path');

		// Формируем путь к папке медиа: baseFolder/media
		const mediaFolder = joinPath(baseFolder, 'media');
		
		// Создаем папку для медиа через файловую систему
		const mediaDir = path.join(this.basePath, mediaFolder);
		if (!fs.existsSync(mediaDir)) {
			fs.mkdirSync(mediaDir, { recursive: true });
		}
		
		// Также создаем через Obsidian API для синхронизации
		try {
			const folders = mediaFolder.split('/').filter(f => f);
			let currentPath = '';
			for (const folder of folders) {
				currentPath = currentPath ? `${currentPath}/${folder}` : folder;
				const sanitizedPath = sanitizePath(currentPath).replace(/\\/g, '/');
				if (!this.plugin.app.vault.getAbstractFileByPath(sanitizedPath)) {
					await this.plugin.app.vault.createFolder(sanitizedPath);
				}
			}
		} catch (error) {
			// Игнорируем ошибки создания папки
		}

		// Обработка фото
		if (message.photo && message.photo.length > 0) {
			// Берем самое большое фото
			const photo = message.photo[message.photo.length - 1];
			const fileName = `photo_${message.message_id}_${message.chat.id}_${photo.file_unique_id}.jpg`;
			const filePath = path.join(mediaDir, fileName);
			
			try {
				await this.downloadFile(photo.file_id, filePath);
				mediaFiles.push({
					fileId: photo.file_id,
					filePath: `${mediaFolder}/${fileName}`,
					fileName: fileName,
					mimeType: 'image/jpeg',
				});
			} catch (error) {
				console.error('Error downloading photo:', error);
			}
		}

		// Обработка видео
		if (message.video) {
			const video = message.video;
			const ext = video.mime_type?.split('/')[1] || 'mp4';
			const fileName = `video_${message.message_id}_${message.chat.id}_${video.file_unique_id}.${ext}`;
			const filePath = path.join(mediaDir, fileName);
			
			try {
				await this.downloadFile(video.file_id, filePath);
				mediaFiles.push({
					fileId: video.file_id,
					filePath: `${mediaFolder}/${fileName}`,
					fileName: fileName,
					mimeType: video.mime_type || 'video/mp4',
				});
			} catch (error) {
				console.error('Error downloading video:', error);
			}
		}

		// Обработка документов
		if (message.document) {
			const doc = message.document;
			const originalName = doc.file_name || `document_${doc.file_unique_id}`;
			const sanitizedName = sanitizePath(originalName);
			const fileName = `doc_${message.message_id}_${message.chat.id}_${sanitizedName}`;
			const filePath = path.join(mediaDir, fileName);
			
			try {
				await this.downloadFile(doc.file_id, filePath);
				mediaFiles.push({
					fileId: doc.file_id,
					filePath: `${mediaFolder}/${fileName}`,
					fileName: fileName,
					mimeType: doc.mime_type,
				});
			} catch (error) {
				console.error('Error downloading document:', error);
			}
		}

		// Обработка аудио
		if (message.audio) {
			const audio = message.audio;
			const ext = audio.mime_type?.split('/')[1] || 'mp3';
			const fileName = `audio_${message.message_id}_${message.chat.id}_${audio.file_unique_id}.${ext}`;
			const filePath = path.join(mediaDir, fileName);
			
			try {
				await this.downloadFile(audio.file_id, filePath);
				mediaFiles.push({
					fileId: audio.file_id,
					filePath: `${mediaFolder}/${fileName}`,
					fileName: fileName,
					mimeType: audio.mime_type || 'audio/mpeg',
				});
			} catch (error) {
				console.error('Error downloading audio:', error);
			}
		}

		// Обработка голосовых сообщений
		if (message.voice) {
			const voice = message.voice;
			const ext = voice.mime_type?.split('/')[1] || 'ogg';
			const fileName = `voice_${message.message_id}_${message.chat.id}_${voice.file_unique_id}.${ext}`;
			const filePath = path.join(mediaDir, fileName);
			
			try {
				await this.downloadFile(voice.file_id, filePath);
				mediaFiles.push({
					fileId: voice.file_id,
					filePath: `${mediaFolder}/${fileName}`,
					fileName: fileName,
					mimeType: voice.mime_type || 'audio/ogg',
				});
			} catch (error) {
				console.error('Error downloading voice:', error);
			}
		}

		return mediaFiles;
	}

	/**
	 * Получает относительный путь к медиафайлу для использования в заметке
	 */
	getRelativePath(mediaFile: MediaFile): string {
		// Возвращаем путь относительно корня хранилища
		return mediaFile.filePath;
	}
}


import { Plugin } from 'obsidian';
import { SyncService } from '../sync/syncService';
import { Logger } from '../utils/logger';

/**
 * Кнопка синхронизации в вертикальной панели (ribbon)
 */
export class RibbonSyncButton {
	private plugin: Plugin;
	private syncService: SyncService;
	private logger: Logger;
	private ribbonIconEl: HTMLElement | null = null;

	constructor(plugin: Plugin, syncService: SyncService, logger: Logger) {
		this.plugin = plugin;
		this.syncService = syncService;
		this.logger = logger;
	}

	/**
	 * Добавляет кнопку синхронизации в ribbon
	 */
	addToRibbon(): void {
		this.ribbonIconEl = this.plugin.addRibbonIcon(
			'message-circle',
			'Синхронизировать Telegram сообщения',
			async () => {
				this.logger.info('Запущена ручная синхронизация из ribbon');
				await this.performSync();
			}
		);
	}

	/**
	 * Добавляет кнопку просмотра логов в ribbon
	 */
	addLogsButtonToRibbon(): void {
		const logsIconEl = this.plugin.addRibbonIcon(
			'file-text',
			'Показать логи плагина',
			async () => {
				this.logger.info('Открытие заметки с логами');
				await this.logger.openLogsNote();
			}
		);
	}

	/**
	 * Выполняет синхронизацию
	 */
	private async performSync(): Promise<void> {
		if (this.ribbonIconEl) {
			this.ribbonIconEl.setAttribute('aria-label', 'Синхронизация...');
		}

		try {
			const result = await this.syncService.sync();
			
			this.logger.info(`Синхронизация завершена: ${result.processed} обработано, ${result.errors} ошибок`);
			
			if (this.ribbonIconEl) {
				if (result.errors > 0) {
					this.ribbonIconEl.setAttribute('aria-label', `⚠️ Ошибок: ${result.errors}`);
				} else if (result.processed > 0) {
					this.ribbonIconEl.setAttribute('aria-label', `✓ Обработано: ${result.processed}`);
				} else {
					this.ribbonIconEl.setAttribute('aria-label', '✓ Нет новых сообщений');
				}

				// Возвращаем обычный label через 3 секунды
				setTimeout(() => {
					if (this.ribbonIconEl) {
						this.ribbonIconEl.setAttribute('aria-label', 'Синхронизировать Telegram сообщения');
					}
				}, 3000);
			}
		} catch (error) {
			this.logger.error('Ошибка синхронизации', error);
			console.error('Sync error:', error);
			
			if (this.ribbonIconEl) {
				this.ribbonIconEl.setAttribute('aria-label', '✗ Ошибка синхронизации');
				setTimeout(() => {
					if (this.ribbonIconEl) {
						this.ribbonIconEl.setAttribute('aria-label', 'Синхронизировать Telegram сообщения');
					}
				}, 3000);
			}
		}
	}

	/**
	 * Удаляет кнопки из ribbon
	 */
	removeFromRibbon(): void {
		if (this.ribbonIconEl) {
			this.ribbonIconEl.remove();
			this.ribbonIconEl = null;
		}
	}
}


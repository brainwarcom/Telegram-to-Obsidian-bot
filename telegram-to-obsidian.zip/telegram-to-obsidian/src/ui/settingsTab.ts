import { App, PluginSettingTab, Setting } from 'obsidian';
import TelegramToObsidianPlugin from '../main';
import { CommandMapping } from '../types';

/**
 * Вкладка настроек плагина
 */
export class TelegramToObsidianSettingTab extends PluginSettingTab {
	plugin: TelegramToObsidianPlugin;

	constructor(app: App, plugin: TelegramToObsidianPlugin) {
		super(app, plugin);
		this.plugin = plugin;
	}

	display(): void {
		const { containerEl } = this;

		containerEl.empty();

		containerEl.createEl('h2', { text: 'Настройки Telegram to Obsidian' });

		// Настройка токена бота
		new Setting(containerEl)
			.setName('Telegram Bot Token')
			.setDesc('Токен вашего Telegram бота (получите у @BotFather)')
			.addText((text) =>
				text
					.setPlaceholder('Введите токен бота')
					.setValue(this.plugin.settings.token)
					.onChange(async (value) => {
						this.plugin.settings.token = value;
						await this.plugin.saveSettings();
						
						// Перезапускаем бота с новым токеном
						if (value) {
							try {
								await this.plugin.restartBot();
							} catch (error) {
								console.error('Error restarting bot:', error);
							}
						} else {
							await this.plugin.stopBot();
						}
					})
			);

		// Настройка дефолтной папки для заметок
		new Setting(containerEl)
			.setName('Папка по умолчанию')
			.setDesc('Папка для сохранения заметок по умолчанию (например: tto или notes/telegram). Заметки будут сохраняться в структуре: папка/YYYY/MM/DD')
			.addText((text) =>
				text
					.setPlaceholder('tto')
					.setValue(this.plugin.settings.defaultFolder || 'tto')
					.onChange(async (value) => {
						this.plugin.settings.defaultFolder = value.trim() || 'tto';
						await this.plugin.saveSettings();
						
						// Обновляем путь для логов в logger
						if (this.plugin.logger) {
							this.plugin.logger.setDefaultFolder(this.plugin.settings.defaultFolder);
						}
					})
			);

		// Кнопка тестирования подключения
		new Setting(containerEl)
			.setName('Тест подключения')
			.setDesc('Проверить подключение к Telegram боту')
			.addButton((button) =>
				button
					.setButtonText('Проверить')
					.setCta()
					.onClick(async () => {
						if (!this.plugin.settings.token) {
							button.setButtonText('Введите токен');
							setTimeout(() => button.setButtonText('Проверить'), 2000);
							return;
						}

						button.setButtonText('Проверка...');
						button.setDisabled(true);

						try {
							// Проверяем, запущен ли бот
							if (!this.plugin.botManager || !this.plugin.botManager.isBotRunning()) {
								// Если бот не запущен, пытаемся его запустить
								if (this.plugin.logger) {
									this.plugin.logger.info('Бот не запущен, пытаемся запустить...');
								}
								try {
									await this.plugin.restartBot();
									// Даем время на инициализацию
									await new Promise(resolve => setTimeout(resolve, 2000));
								} catch (startError) {
									if (this.plugin.logger) {
										this.plugin.logger.error('Ошибка при запуске бота', startError);
									}
									button.setButtonText('✗ Не удалось запустить');
									setTimeout(() => {
										button.setButtonText('Проверить');
										button.setDisabled(false);
									}, 3000);
									return;
								}
							}

							// Получаем информацию о боте
							const info = await this.plugin.getBotInfo();
							if (info && info.id) {
								const username = info.username || 'без имени';
								button.setButtonText(`✓ ${username}`);
								if (this.plugin.logger) {
									this.plugin.logger.info('✅ Проверка подключения: успешно', {
										bot_id: info.id,
										username: info.username,
										first_name: info.first_name
									});
								}
								setTimeout(() => {
									button.setButtonText('Проверить');
									button.setDisabled(false);
								}, 3000);
							} else {
								// Если info === null, бот не инициализирован
								if (this.plugin.logger) {
									this.plugin.logger.warn('⚠️ Проверка подключения: бот не инициализирован');
								}
								button.setButtonText('✗ Бот не запущен');
								setTimeout(() => {
									button.setButtonText('Проверить');
									button.setDisabled(false);
								}, 3000);
							}
						} catch (error: any) {
							const errorMsg = error?.message || String(error);
							if (this.plugin.logger) {
								this.plugin.logger.error('❌ Ошибка при проверке подключения', {
									error: errorMsg,
									code: error?.code,
									response: error?.response?.body
								});
							}
							button.setButtonText('✗ Ошибка подключения');
							setTimeout(() => {
								button.setButtonText('Проверить');
								button.setDisabled(false);
							}, 3000);
						}
					})
			);

		containerEl.createEl('hr');

		// Кнопка открытия логов
		new Setting(containerEl)
			.setName('Просмотр логов')
			.setDesc('Открыть файл с логами плагина')
			.addButton((button) =>
				button
					.setButtonText('Открыть логи')
					.setCta()
					.onClick(async () => {
						if (this.plugin.logger) {
							await this.plugin.logger.openLogsNote();
						}
					})
			);

		// Кнопка диагностики
		new Setting(containerEl)
			.setName('Диагностика бота')
			.setDesc('Показать подробную информацию о состоянии бота')
			.addButton((button) =>
				button
					.setButtonText('Диагностика')
					.onClick(async () => {
						if (!this.plugin.botManager) {
							button.setButtonText('Бот не инициализирован');
							setTimeout(() => button.setButtonText('Диагностика'), 2000);
							return;
						}

						button.setButtonText('Проверка...');
						button.setDisabled(true);

						try {
							const diagnostic = await this.plugin.botManager.getDiagnosticInfo();
							
							if (this.plugin.logger) {
								this.plugin.logger.info('📊 Диагностика бота', diagnostic);
							}

							if (diagnostic.status === 'running') {
								button.setButtonText(`✓ OK (polling: ${diagnostic.isPolling})`);
							} else {
								button.setButtonText(`✗ ${diagnostic.status}`);
							}

							setTimeout(() => {
								button.setButtonText('Диагностика');
								button.setDisabled(false);
							}, 3000);
						} catch (error) {
							button.setButtonText('✗ Ошибка');
							setTimeout(() => {
								button.setButtonText('Диагностика');
								button.setDisabled(false);
							}, 3000);
						}
					})
			);

		// Кнопка сброса webhook
		new Setting(containerEl)
			.setName('Сброс webhook')
			.setDesc('Принудительно сбросить webhook и очистить предыдущие подключения (помогает при ошибке 409 Conflict)')
			.addButton((button) =>
				button
					.setButtonText('Сбросить webhook')
					.setWarning()
					.onClick(async () => {
						if (!this.plugin.settings.token) {
							button.setButtonText('Введите токен');
							setTimeout(() => button.setButtonText('Сбросить webhook'), 2000);
							return;
						}

						if (!this.plugin.botManager) {
							button.setButtonText('Бот не инициализирован');
							setTimeout(() => button.setButtonText('Сбросить webhook'), 2000);
							return;
						}

						button.setButtonText('Сброс...');
						button.setDisabled(true);

						try {
							await this.plugin.botManager.resetWebhook(this.plugin.settings.token);
							button.setButtonText('✓ Сброшен');
							
							// Перезапускаем бота
							setTimeout(async () => {
								await this.plugin.restartBot();
							}, 1000);
							
							setTimeout(() => {
								button.setButtonText('Сбросить webhook');
								button.setDisabled(false);
							}, 3000);
						} catch (error) {
							button.setButtonText('✗ Ошибка');
							setTimeout(() => {
								button.setButtonText('Сбросить webhook');
								button.setDisabled(false);
							}, 3000);
						}
					})
			);

		containerEl.createEl('hr');

		// Заголовок раздела команд
		containerEl.createEl('h3', { text: 'Команды и папки' });
		containerEl.createEl('p', {
			text: 'Настройте команды, которые будут определять папку для сохранения заметок. Если сообщение или ответ содержит команду, заметка будет сохранена в указанную папку.',
			cls: 'setting-item-description',
		});

		// Список существующих команд
		const commandsContainer = containerEl.createEl('div', { cls: 'commands-list' });

		this.renderCommands(commandsContainer);

		// Кнопка добавления новой команды
		const addCommandSetting = new Setting(containerEl)
			.setName('Добавить команду')
			.setDesc('Создать новую команду для сохранения в определенную папку')
			.addText((text) =>
				text
					.setPlaceholder('Команда (например: work)')
					.setValue('')
			)
			.addText((text) =>
				text
					.setPlaceholder('Папка назначения (например: work/notes)')
					.setValue('')
			)
			.addButton((button) =>
				button
					.setButtonText('+ Добавить')
					.setCta()
					.onClick(async () => {
						const commandInput = addCommandSetting.components[0] as any;
						const folderInput = addCommandSetting.components[1] as any;
						
						const command = commandInput.inputEl.value.trim();
						const folder = folderInput.inputEl.value.trim();

						if (!command) {
							return;
						}

						if (!folder) {
							return;
						}

						if (this.plugin.commandsManager) {
							try {
								await this.plugin.commandsManager.addCommand(command, folder);
								await this.plugin.saveSettings();
								
								// Очищаем поля ввода
								commandInput.inputEl.value = '';
								folderInput.inputEl.value = '';
								
								// Обновляем интерфейс
								this.display();
							} catch (error) {
								console.error('Error adding command:', error);
							}
						}
					})
			);
	}

	/**
	 * Отображает список команд
	 */
	private renderCommands(container: HTMLElement): void {
		container.empty();

		if (!this.plugin.commandsManager) return;

		const commands = this.plugin.commandsManager.getCommands();

		if (commands.length === 0) {
			container.createEl('p', {
				text: 'Команды не настроены. По умолчанию заметки сохраняются в папку tto/YYYY/MM/DD/',
				cls: 'setting-item-description',
			});
			return;
		}

		for (let i = 0; i < commands.length; i++) {
			const cmd = commands[i];
			const settingItem = new Setting(container)
				.setName('')
				.setDesc('')
				.addText((text) => {
					text
						.setPlaceholder('Команда')
						.setValue(cmd.command)
						.onChange(async (value) => {
							if (value.trim() && value.trim() !== cmd.command && this.plugin.commandsManager) {
								const newCommand = value.trim().replace(/^\//, '').toLowerCase();
								// Удаляем старую команду и добавляем новую
								await this.plugin.commandsManager.removeCommand(cmd.command);
								await this.plugin.commandsManager.addCommand(newCommand, cmd.folder);
								await this.plugin.saveSettings();
								this.display();
							}
						});
					// Добавляем префикс "/" перед полем
					const inputEl = text.inputEl;
					inputEl.style.paddingLeft = '20px';
					const prefix = document.createElement('span');
					prefix.textContent = '/';
					prefix.style.position = 'absolute';
					prefix.style.left = '8px';
					prefix.style.color = 'var(--text-muted)';
					prefix.style.pointerEvents = 'none';
					const parentEl = inputEl.parentElement;
					if (parentEl) {
						parentEl.style.position = 'relative';
						parentEl.appendChild(prefix);
					}
				})
				.addText((text) => {
					text
						.setPlaceholder('Папка назначения')
						.setValue(cmd.folder)
						.onChange(async (value) => {
							if (value.trim() && value.trim() !== cmd.folder && this.plugin.commandsManager) {
								await this.plugin.commandsManager.addCommand(cmd.command, value.trim());
								await this.plugin.saveSettings();
							}
						});
				})
				.addButton((button) =>
					button
						.setButtonText('Удалить')
						.setWarning()
						.onClick(async () => {
							if (confirm(`Удалить команду /${cmd.command}?`) && this.plugin.commandsManager) {
								await this.plugin.commandsManager.removeCommand(cmd.command);
								await this.plugin.saveSettings();
								this.display();
							}
						})
				);

			// Убираем границы у Setting
			const settingEl = settingItem.settingEl;
			settingEl.style.borderTop = 'none';
			settingEl.style.borderBottom = 'none';
			settingEl.style.paddingTop = '8px';
			settingEl.style.paddingBottom = '8px';

			// Добавляем разделитель между командами (кроме последней)
			if (i < commands.length - 1) {
				const hr = container.createEl('hr');
				hr.style.margin = '8px 0';
			}
		}
	}
}


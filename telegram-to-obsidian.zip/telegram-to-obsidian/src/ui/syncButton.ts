import { Plugin } from 'obsidian';
import { SyncService } from '../sync/syncService';

/**
 * Кнопка для ручной синхронизации
 */
export class SyncButton {
	private plugin: Plugin;
	private syncService: SyncService;
	private buttonEl: HTMLElement | null = null;
	private statusBarItemEl: HTMLElement | null = null;

	constructor(plugin: Plugin, syncService: SyncService) {
		this.plugin = plugin;
		this.syncService = syncService;
	}

	/**
	 * Добавляет кнопку в статус-бар
	 */
	addToStatusBar(): void {
		const statusBarItem = this.plugin.addStatusBarItem();
		statusBarItem.classList.add('mod-clickable');
		statusBarItem.createEl('span', { text: '🔄 Telegram Sync', cls: 'sync-button' });
		
		statusBarItem.addEventListener('click', async () => {
			await this.performSync();
		});

		this.statusBarItemEl = statusBarItem;
		this.buttonEl = statusBarItem.querySelector('.sync-button') as HTMLElement;
	}

	/**
	 * Выполняет синхронизацию
	 */
	private async performSync(): Promise<void> {
		if (!this.buttonEl) return;

		const originalText = this.buttonEl.textContent || '';
		this.buttonEl.textContent = '🔄 Синхронизация...';
		
		if (this.statusBarItemEl) {
			this.statusBarItemEl.classList.remove('mod-clickable');
		}

		try {
			const result = await this.syncService.sync();
			
			if (result.errors > 0) {
				this.buttonEl.textContent = `⚠️ Ошибок: ${result.errors}`;
				setTimeout(() => {
					if (this.buttonEl) {
						this.buttonEl.textContent = originalText;
					}
					if (this.statusBarItemEl) {
						this.statusBarItemEl.classList.add('mod-clickable');
					}
				}, 3000);
			} else if (result.processed > 0) {
				this.buttonEl.textContent = `✓ Обработано: ${result.processed}`;
				setTimeout(() => {
					if (this.buttonEl) {
						this.buttonEl.textContent = originalText;
					}
					if (this.statusBarItemEl) {
						this.statusBarItemEl.classList.add('mod-clickable');
					}
				}, 3000);
			} else {
				this.buttonEl.textContent = '✓ Нет новых сообщений';
				setTimeout(() => {
					if (this.buttonEl) {
						this.buttonEl.textContent = originalText;
					}
					if (this.statusBarItemEl) {
						this.statusBarItemEl.classList.add('mod-clickable');
					}
				}, 2000);
			}
		} catch (error) {
			console.error('Sync error:', error);
			this.buttonEl.textContent = '✗ Ошибка';
			setTimeout(() => {
				if (this.buttonEl) {
					this.buttonEl.textContent = originalText;
				}
				if (this.statusBarItemEl) {
					this.statusBarItemEl.classList.add('mod-clickable');
				}
			}, 3000);
		}
	}

	/**
	 * Удаляет кнопку из статус-бара
	 */
	removeFromStatusBar(): void {
		if (this.statusBarItemEl) {
			this.statusBarItemEl.remove();
			this.statusBarItemEl = null;
			this.buttonEl = null;
		}
	}
}


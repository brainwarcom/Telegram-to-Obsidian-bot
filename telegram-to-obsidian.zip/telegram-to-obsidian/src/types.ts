/**
 * Типы для плагина Telegram to Obsidian
 */

export interface TelegramMessage {
	message_id: number;
	date: number;
	text?: string;
	caption?: string;
	chat: {
		id: number;
		title?: string;
		username?: string;
	};
	from?: {
		id: number;
		username?: string;
		first_name?: string;
	};
	reply_to_message?: TelegramMessage;
	photo?: Array<{
		file_id: string;
		file_unique_id: string;
		file_size?: number;
		width: number;
		height: number;
	}>;
	video?: {
		file_id: string;
		file_unique_id: string;
		width: number;
		height: number;
		duration: number;
		mime_type?: string;
		file_size?: number;
	};
	document?: {
		file_id: string;
		file_unique_id: string;
		file_name?: string;
		mime_type?: string;
		file_size?: number;
	};
	audio?: {
		file_id: string;
		file_unique_id: string;
		duration: number;
		performer?: string;
		title?: string;
		mime_type?: string;
		file_size?: number;
	};
	voice?: {
		file_id: string;
		file_unique_id: string;
		duration: number;
		mime_type?: string;
		file_size?: number;
	};
	sticker?: {
		file_id: string;
		file_unique_id: string;
		width: number;
		height: number;
		emoji?: string;
		set_name?: string;
		file_size?: number;
	};
}

export interface QueuedMessage {
	message: TelegramMessage;
	processed: boolean;
	queuedAt: number;
}

export interface CommandMapping {
	command: string; // Команда без слэша, например "work"
	folder: string;  // Папка назначения, например "work/notes"
}

export interface PluginSettings {
	token: string;
	commands: CommandMapping[];
	lastSyncTimestamp: number;
	defaultFolder: string;
}

export interface MediaFile {
	fileId: string;
	filePath: string;
	fileName: string;
	mimeType?: string;
}


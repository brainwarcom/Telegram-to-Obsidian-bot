import { Plugin } from 'obsidian';
import { TelegramMessage, QueuedMessage } from '../types';
import { MessageQueue } from '../storage/messageQueue';
import { CommandsManager } from '../storage/commands';
import { NoteCreator } from './noteCreator';
import { MediaDownloader } from '../media/mediaDownloader';
import { formatDateForPath, timestampToDate } from '../utils/dateUtils';
import { joinPath } from '../utils/fileUtils';
import { Logger } from '../utils/logger';

/**
 * Сервис синхронизации сообщений из Telegram в Obsidian
 */
export class SyncService {
	private plugin: Plugin;
	private messageQueue: MessageQueue;
	private commandsManager: CommandsManager;
	private noteCreator: NoteCreator;
	private mediaDownloader: MediaDownloader | null = null;
	private logger: Logger;
	private botManager: any = null;

	constructor(
		plugin: Plugin,
		messageQueue: MessageQueue,
		commandsManager: CommandsManager,
		botToken: string,
		logger: Logger
	) {
		this.plugin = plugin;
		this.messageQueue = messageQueue;
		this.commandsManager = commandsManager;
		this.noteCreator = new NoteCreator(plugin);
		this.logger = logger;
		
		if (botToken) {
			this.mediaDownloader = new MediaDownloader(plugin, botToken);
		}
	}

	/**
	 * Получает дефолтную папку из настроек плагина
	 */
	private getDefaultFolder(): string {
		const settings = (this.plugin as any).settings;
		return settings?.defaultFolder || 'tto';
	}

	/**
	 * Получает базовую папку для сообщения (без дат)
	 * Используется для сохранения медиа и других ресурсов
	 */
	private getBaseFolder(message: TelegramMessage): string {
		// Проверяем, есть ли команда в тексте исходного сообщения или ответа
		let command: string | null = null;
		
		// Проверяем текст текущего сообщения
		if (message.text || message.caption) {
			const text = message.text || message.caption || '';
			command = this.commandsManager.findCommandInText(text);
		}
		
		// Если это ответ, проверяем исходное сообщение
		if (!command && message.reply_to_message) {
			const replyText = message.reply_to_message.text || message.reply_to_message.caption;
			if (replyText) {
				command = this.commandsManager.findCommandInText(replyText);
			}
		}
		
		// Если нашли команду, используем её папку
		if (command) {
			const folder = this.commandsManager.getFolderForCommand(command);
			if (folder) {
				return folder;
			}
		}
		
		// По умолчанию используем дефолтную папку (без дат)
		return this.getDefaultFolder();
	}

	/**
	 * Устанавливает менеджер бота для отправки реакций
	 */
	setBotManager(botManager: any): void {
		this.botManager = botManager;
	}

	/**
	 * Определяет папку назначения для сообщения
	 */
	private determineFolder(message: TelegramMessage): string {
		// Проверяем, есть ли команда в тексте исходного сообщения или ответа
		let command: string | null = null;
		
		// Проверяем текст текущего сообщения
		if (message.text || message.caption) {
			const text = message.text || message.caption || '';
			this.logger.debug(`Поиск команды в тексте сообщения: "${text}"`);
			command = this.commandsManager.findCommandInText(text);
			if (command) {
				this.logger.debug(`Найдена команда: ${command}`);
			}
		}
		
		// Если это ответ, проверяем исходное сообщение
		if (!command && message.reply_to_message) {
			const replyText = message.reply_to_message.text || message.reply_to_message.caption;
			if (replyText) {
				this.logger.debug(`Поиск команды в исходном сообщении: "${replyText}"`);
				command = this.commandsManager.findCommandInText(replyText);
				if (command) {
					this.logger.debug(`Найдена команда в исходном сообщении: ${command}`);
				}
			}
		}
		
		// Если нашли команду, используем её папку
		if (command) {
			const folder = this.commandsManager.getFolderForCommand(command);
			if (folder) {
				this.logger.debug(`Используется папка для команды ${command}: ${folder}`);
				return folder;
			} else {
				this.logger.warn(`Команда ${command} найдена, но папка не настроена`);
			}
		} else {
			this.logger.debug('Команда не найдена, используется папка по умолчанию');
		}
		
		// По умолчанию используем структуру defaultFolder/YYYY/MM/DD
		const defaultFolder = this.getDefaultFolder();
		this.logger.debug(`Используется дефолтная папка: ${defaultFolder}`);
		const date = timestampToDate(message.date);
		const datePath = formatDateForPath(date);
		const finalPath = joinPath(defaultFolder, datePath);
		this.logger.debug(`Итоговый путь для сохранения: ${finalPath}`);
		return finalPath;
	}

	/**
	 * Группирует сообщения: исходные и ответы на них
	 */
	private groupMessages(messages: QueuedMessage[]): Map<number, { main: QueuedMessage; replies: QueuedMessage[] }> {
		const groups = new Map<number, { main: QueuedMessage; replies: QueuedMessage[] }>();
		
		// Сначала находим все основные сообщения (не ответы)
		for (const queued of messages) {
			if (!queued.message.reply_to_message) {
				if (!groups.has(queued.message.message_id)) {
					groups.set(queued.message.message_id, {
						main: queued,
						replies: [],
					});
				}
			}
		}
		
		this.logger.debug(`Группировка сообщений: найдено ${groups.size} основных сообщений, всего сообщений: ${messages.length}`);
		
		// Затем добавляем ответы к соответствующим сообщениям
		let repliesCount = 0;
		for (const queued of messages) {
			if (queued.message.reply_to_message) {
				const replyToId = queued.message.reply_to_message.message_id;
				const replyToChatId = queued.message.reply_to_message.chat.id;
				
				// Ищем основное сообщение в той же группе
				let found = false;
				for (const [mainId, group] of groups.entries()) {
					const mainChatId = group.main.message.chat.id;
					if (replyToId === mainId && replyToChatId === mainChatId) {
						group.replies.push(queued);
						repliesCount++;
						found = true;
						this.logger.debug(`Ответ ${queued.message.message_id} добавлен к основному сообщению ${mainId}`);
						break;
					}
				}
				
				if (!found) {
					this.logger.debug(`Ответ ${queued.message.message_id} не найден основное сообщение ${replyToId} в чате ${replyToChatId}`);
				}
			}
		}
		
		this.logger.debug(`Группировка завершена: ${repliesCount} ответов добавлено к основным сообщениям`);
		
		return groups;
	}

	/**
	 * Синхронизирует сообщения из очереди
	 */
	async sync(): Promise<{ processed: number; errors: number }> {
		await this.messageQueue.load();
		await this.commandsManager.load();
		
		const unprocessed = this.messageQueue.getUnprocessedMessages();
		
		if (unprocessed.length === 0) {
			return { processed: 0, errors: 0 };
		}
		
		// Группируем сообщения: основные и ответы
		const groups = this.groupMessages(unprocessed);
		
		let processed = 0;
		let errors = 0;
		
		// Обрабатываем ответы, которые ссылаются на уже обработанные сообщения
		const orphanReplies: QueuedMessage[] = [];
		for (const queued of unprocessed) {
			if (queued.message.reply_to_message) {
				const replyToId = queued.message.reply_to_message.message_id;
				const replyToChatId = queued.message.reply_to_message.chat.id;
				
				// Проверяем, есть ли это сообщение в группах
				let foundInGroups = false;
				for (const [mainId, group] of groups.entries()) {
					if (replyToId === mainId) {
						foundInGroups = true;
						break;
					}
				}
				
				// Если не найдено в группах, проверяем, обработано ли основное сообщение
				if (!foundInGroups) {
					if (this.messageQueue.isProcessed(replyToId, replyToChatId)) {
						orphanReplies.push(queued);
						this.logger.debug(`Ответ ${queued.message.message_id} ссылается на уже обработанное сообщение ${replyToId} в чате ${replyToChatId}`);
					} else {
						this.logger.debug(`Ответ ${queued.message.message_id} ссылается на сообщение ${replyToId}, которое еще не обработано и не в группах`);
					}
				}
			}
		}
		
		this.logger.debug(`Найдено ${orphanReplies.length} ответов на уже обработанные сообщения`);
		
		// Обрабатываем ответы на уже обработанные сообщения
		for (const replyQueued of orphanReplies) {
			const replyMessage = replyQueued.message;
			const replyToId = replyMessage.reply_to_message!.message_id;
			const replyToChatId = replyMessage.reply_to_message!.chat.id;
			
			try {
				// Получаем основное сообщение из очереди (даже если оно обработано)
				const mainQueued = this.messageQueue.getMessage(replyToId, replyToChatId);
				if (!mainQueued) {
					this.logger.warn(`Основное сообщение ${replyToId} не найдено в очереди для ответа ${replyMessage.message_id}`);
					continue;
				}
				
				const mainMessage = mainQueued.message;
				const folder = this.determineFolder(mainMessage);
				
				// Получаем базовую папку для медиа ответа
				const replyBaseFolder = this.getBaseFolder(replyMessage);
				
				// Скачиваем медиа для ответа
				let replyMediaFiles: any[] = [];
				if (this.mediaDownloader && (replyMessage.photo || replyMessage.video || replyMessage.document || replyMessage.audio || replyMessage.voice)) {
					try {
						replyMediaFiles = await this.mediaDownloader.processMedia(replyMessage, replyBaseFolder);
					} catch (error) {
						this.logger.error('Ошибка при обработке медиа ответа', error);
					}
				}
				
				// Ищем заметку по ID основного сообщения
				const notePath = await this.noteCreator.findNoteByMessageId(replyToId, folder);
				
				// Всегда создаем отдельную заметку для ответа со ссылкой на основное сообщение
				// Это более надежно, чем пытаться редактировать существующую заметку
				const replyContent = this.noteCreator.createReplyNoteContent(
					replyMessage, 
					replyMediaFiles, 
					replyToId,
					notePath
				);
				const replyFileName = this.noteCreator.createFileName(replyMessage);
				const savedPath = await this.noteCreator.saveNote(folder, replyFileName, replyContent);
				
				if (notePath) {
					this.logger.info(`Создана заметка для ответа ${replyMessage.message_id} со ссылкой на основное сообщение: ${savedPath}`);
				} else {
					this.logger.info(`Создана заметка для ответа ${replyMessage.message_id} (основное сообщение ${replyToId} не найдено): ${savedPath}`);
				}
				
				await this.messageQueue.markAsProcessed(replyMessage.message_id, replyMessage.chat.id);
				processed++;
			} catch (error) {
				this.logger.error(`Ошибка при обработке ответа ${replyMessage.message_id} на обработанное сообщение`, error);
				errors++;
			}
		}
		
		// Создаем Set из ID обработанных orphan replies, чтобы не обрабатывать их дважды
		const processedOrphanReplyIds = new Set(orphanReplies.map(r => r.message.message_id));
		
		// Обрабатываем каждую группу
		for (const [mainId, group] of groups.entries()) {
			const mainMessage = group.main.message;
			let success = false;
			
			try {
				this.logger.info(`Обработка сообщения ${mainMessage.message_id}`, {
					chat_id: mainMessage.chat.id,
					has_text: !!mainMessage.text,
					has_photo: !!mainMessage.photo,
				});

				const folder = this.determineFolder(mainMessage);
				this.logger.debug(`Определена папка: ${folder}`);
				
				// Получаем базовую папку для медиа (без дат)
				const baseFolder = this.getBaseFolder(mainMessage);
				
				// Скачиваем медиа для основного сообщения
				let mainMediaFiles: any[] = [];
				if (this.mediaDownloader && (mainMessage.photo || mainMessage.video || mainMessage.document || mainMessage.audio || mainMessage.voice)) {
					try {
						this.logger.info('Скачивание медиафайлов для основного сообщения');
						mainMediaFiles = await this.mediaDownloader.processMedia(mainMessage, baseFolder);
						this.logger.info(`Скачано ${mainMediaFiles.length} медиафайлов в папку ${baseFolder}/media`);
					} catch (error) {
						this.logger.error('Ошибка при обработке медиа основного сообщения', error);
						console.error('Error processing main message media:', error);
					}
				}
				
				// Обрабатываем ответы (исключаем уже обработанные orphan replies)
				const replies: Array<{ message: TelegramMessage; mediaFiles: any[] }> = [];
				for (const replyQueued of group.replies) {
					// Пропускаем ответы, которые уже были обработаны как orphan replies
					if (processedOrphanReplyIds.has(replyQueued.message.message_id)) {
						this.logger.debug(`Пропущен ответ ${replyQueued.message.message_id}, уже обработан как orphan reply`);
						continue;
					}
					
					const replyMessage = replyQueued.message;
					// Используем ту же базовую папку, что и для основного сообщения
					const replyBaseFolder = this.getBaseFolder(replyMessage);
					let replyMediaFiles: any[] = [];
					
					if (this.mediaDownloader && (replyMessage.photo || replyMessage.video || replyMessage.document || replyMessage.audio || replyMessage.voice)) {
						try {
							replyMediaFiles = await this.mediaDownloader.processMedia(replyMessage, replyBaseFolder);
						} catch (error) {
							console.error('Error processing reply media:', error);
						}
					}
					
					replies.push({
						message: replyMessage,
						mediaFiles: replyMediaFiles,
					});
					
					// Помечаем ответ как обработанный
					await this.messageQueue.markAsProcessed(
						replyMessage.message_id,
						replyMessage.chat.id
					);
				}
				
				// Создаем содержимое заметки
				const content = this.noteCreator.createNoteContent(
					mainMessage,
					mainMediaFiles,
					replies
				);
				
				// Создаем имя файла
				const fileName = this.noteCreator.createFileName(mainMessage);
				
				// Сохраняем заметку
				const savedPath = await this.noteCreator.saveNote(folder, fileName, content);
				this.logger.info(`Заметка сохранена: ${savedPath}`);
				
				// Помечаем основное сообщение как обработанное
				await this.messageQueue.markAsProcessed(
					mainMessage.message_id,
					mainMessage.chat.id
				);
				
				success = true;
				processed++;

				// Отправляем реакцию ✅ на успешно синхронизированное сообщение
				if (this.botManager) {
					try {
						await this.botManager.setReaction(mainMessage.chat.id, mainMessage.message_id, '✅');
					} catch (error) {
						this.logger.warn('Не удалось установить реакцию ✅', error);
					}
				}
			} catch (error) {
				this.logger.error(`Ошибка при обработке группы сообщений ${mainMessage.message_id}`, error);
				console.error('Error processing message group:', error);
				errors++;

				// Отправляем реакцию 💀 на неудачно синхронизированное сообщение
				if (this.botManager) {
					try {
						await this.botManager.setReaction(mainMessage.chat.id, mainMessage.message_id, '💀');
					} catch (error) {
						this.logger.warn('Не удалось установить реакцию 💀', error);
					}
				}
			}
		}
		
		// Сохраняем время последней синхронизации
		await this.messageQueue.saveLastSync(Math.floor(Date.now() / 1000));
		
		return { processed, errors };
	}

	/**
	 * Обновляет токен бота для загрузки медиа
	 */
	updateBotToken(botToken: string): void {
		if (botToken) {
			this.mediaDownloader = new MediaDownloader(this.plugin, botToken);
		} else {
			this.mediaDownloader = null;
		}
	}
}


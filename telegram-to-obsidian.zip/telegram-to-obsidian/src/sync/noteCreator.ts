import { Plugin } from 'obsidian';
import { TelegramMessage, MediaFile } from '../types';
import { formatDateForNote, timestampToDate } from '../utils/dateUtils';
import { sanitizePath } from '../utils/fileUtils';

/**
 * Создание Markdown заметок из сообщений Telegram
 */
export class NoteCreator {
	private plugin: Plugin;

	constructor(plugin: Plugin) {
		this.plugin = plugin;
	}

	/**
	 * Создает содержимое заметки из сообщения
	 */
	createNoteContent(
		message: TelegramMessage,
		mediaFiles: MediaFile[],
		replies: Array<{ message: TelegramMessage; mediaFiles: MediaFile[] }> = []
	): string {
		const date = timestampToDate(message.date);
		const dateStr = formatDateForNote(date);
		
		// Заголовок заметки
		let content = `# ${dateStr}\n\n`;
		
		// Текст сообщения
		const text = message.text || message.caption || '';
		if (text) {
			content += `${text}\n\n`;
		}
		
		// Медиафайлы текущего сообщения
		if (mediaFiles.length > 0) {
			content += '\n';
			for (const media of mediaFiles) {
				if (media.mimeType?.startsWith('image/')) {
					content += `![[${media.filePath}]]\n\n`;
				} else if (media.mimeType?.startsWith('video/')) {
					content += `[[${media.filePath}]]\n\n`;
				} else {
					content += `[[${media.filePath}]]\n\n`;
				}
			}
		}
		
		// Информация об отправителе (если есть)
		if (message.from) {
			const fromInfo = message.from.username 
				? `@${message.from.username}`
				: message.from.first_name || 'Unknown';
			content += `\n*От: ${fromInfo}*\n\n`;
		}
		
		// Ответы на сообщение
		if (replies.length > 0) {
			content += '\n---\n';
			content += '\n**Ответы:**\n\n';
			
			for (const reply of replies) {
				const replyDate = timestampToDate(reply.message.date);
				const replyDateStr = formatDateForNote(replyDate);
				const replyText = reply.message.text || reply.message.caption || '';
				
				content += `- **${replyDateStr}**\n`;
				if (replyText) {
					content += `  ${replyText}\n`;
				}
				
				// Медиафайлы в ответе
				if (reply.mediaFiles.length > 0) {
					for (const media of reply.mediaFiles) {
						if (media.mimeType?.startsWith('image/')) {
							content += `  ![[${media.filePath}]]\n`;
						} else {
							content += `  [[${media.filePath}]]\n`;
						}
					}
				}
				
				// Информация об отправителе ответа
				if (reply.message.from) {
					const fromInfo = reply.message.from.username 
						? `@${reply.message.from.username}`
						: reply.message.from.first_name || 'Unknown';
					content += `  *От: ${fromInfo}*\n`;
				}
				
				content += '\n';
			}
		}
		
		return content.trim();
	}

	/**
	 * Создает содержимое заметки для ответа со ссылкой на основное сообщение
	 */
	createReplyNoteContent(
		replyMessage: TelegramMessage,
		replyMediaFiles: MediaFile[],
		replyToMessageId: number,
		mainNotePath: string | null
	): string {
		const date = timestampToDate(replyMessage.date);
		const dateStr = formatDateForNote(date);
		
		// Заголовок заметки
		let content = `# Ответ: ${dateStr}\n\n`;
		
		// Ссылка на основное сообщение
		if (mainNotePath) {
			const noteName = mainNotePath.split('/').pop()?.replace('.md', '') || `сообщение ${replyToMessageId}`;
			content += `**Ответ на:** [[${noteName}]]\n\n`;
		} else {
			content += `**Ответ на сообщение:** #${replyToMessageId}\n\n`;
		}
		
		// Текст ответа
		const text = replyMessage.text || replyMessage.caption || '';
		if (text) {
			content += `${text}\n\n`;
		}
		
		// Медиафайлы в ответе
		if (replyMediaFiles.length > 0) {
			content += '\n';
			for (const media of replyMediaFiles) {
				if (media.mimeType?.startsWith('image/')) {
					content += `![[${media.filePath}]]\n\n`;
				} else if (media.mimeType?.startsWith('video/')) {
					content += `[[${media.filePath}]]\n\n`;
				} else {
					content += `[[${media.filePath}]]\n\n`;
				}
			}
		}
		
		// Информация об отправителе ответа
		if (replyMessage.from) {
			const fromInfo = replyMessage.from.username 
				? `@${replyMessage.from.username}`
				: replyMessage.from.first_name || 'Unknown';
			content += `\n*От: ${fromInfo}*\n\n`;
		}
		
		return content.trim();
	}

	/**
	 * Создает имя файла для заметки
	 */
	createFileName(message: TelegramMessage): string {
		const date = timestampToDate(message.date);
		const dateStr = formatDateForNote(date);
		
		// Создаем имя файла из даты и первых символов текста
		const text = message.text || message.caption || '';
		// Заменяем все недопустимые символы, пробелы и обратные слеши на подчеркивания
		let fileName = dateStr.replace(/[<>:"|?*\x00-\x1f\\]/g, '_').replace(/\s+/g, '_');
		
		// Если есть текст, добавляем его превью
		if (text) {
			const preview = text.substring(0, 50).replace(/[<>:"|?*\x00-\x1f\\]/g, '').trim();
			if (preview) {
				const sanitized = sanitizePath(preview).replace(/[\\\/]/g, '_');
				fileName += '_' + sanitized;
			}
		} else {
			// Если нет текста, добавляем тип медиа или просто "media"
			if (message.photo) {
				fileName += '_photo';
			} else if (message.video) {
				fileName += '_video';
			} else if (message.document) {
				fileName += '_document';
			} else if (message.audio) {
				fileName += '_audio';
			} else if (message.voice) {
				fileName += '_voice';
			} else {
				fileName += '_message';
			}
		}
		
		// Добавляем ID сообщения для уникальности
		fileName += `_${message.message_id}`;
		
		// Убираем двойные подчеркивания и обратные слеши
		fileName = fileName.replace(/[\\\/]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
		
		// Ограничиваем длину имени файла
		if (fileName.length > 200) {
			fileName = fileName.substring(0, 200);
		}
		
		return `${fileName}.md`;
	}

	/**
	 * Сохраняет заметку в файл
	 */
	async saveNote(
		folderPath: string,
		fileName: string,
		content: string
	): Promise<string> {
		// Нормализуем путь, убирая обратные слеши и двойные слеши
		const normalizedFolder = folderPath ? folderPath.replace(/\\/g, '/').replace(/\/+/g, '/') : '';
		const normalizedFileName = fileName.replace(/\\/g, '/');
		const fullPath = normalizedFolder ? `${normalizedFolder}/${normalizedFileName}` : normalizedFileName;
		const sanitizedPath = sanitizePath(fullPath).replace(/\\/g, '/');
		
		try {
			// Создаем папку, если её нет
			if (normalizedFolder) {
				const folders = normalizedFolder.split('/').filter(f => f);
				let currentPath = '';
				for (const folder of folders) {
					currentPath = currentPath ? `${currentPath}/${folder}` : folder;
					const sanitizedFolder = sanitizePath(currentPath).replace(/\\/g, '/');
					if (!this.plugin.app.vault.getAbstractFileByPath(sanitizedFolder)) {
						await this.plugin.app.vault.createFolder(sanitizedFolder);
					}
				}
			}
			
			// Создаем или обновляем файл
			const existingFile = this.plugin.app.vault.getAbstractFileByPath(sanitizedPath);
			if (existingFile) {
				await this.plugin.app.vault.modify(existingFile as any, content);
			} else {
				await this.plugin.app.vault.create(sanitizedPath, content);
			}
			
			return sanitizedPath;
		} catch (error) {
			console.error('Error saving note:', error);
			throw error;
		}
	}

	/**
	 * Находит заметку по ID сообщения
	 */
	async findNoteByMessageId(messageId: number, folderPath: string): Promise<string | null> {
		try {
			// Ищем файлы в папке, которые содержат ID сообщения в имени
			const folder = this.plugin.app.vault.getAbstractFileByPath(folderPath);
			if (!folder || !(folder as any).children) {
				return null;
			}
			
			// Ищем файл, имя которого заканчивается на _${messageId}.md
			const pattern = `_${messageId}.md`;
			for (const child of (folder as any).children) {
				if (child.name && child.name.endsWith(pattern)) {
					return folderPath ? `${folderPath}/${child.name}` : child.name;
				}
			}
			
			return null;
		} catch (error) {
			return null;
		}
	}

	/**
	 * Добавляет ответ к существующей заметке
	 */
	async addReplyToNote(
		notePath: string,
		replyMessage: TelegramMessage,
		replyMediaFiles: MediaFile[]
	): Promise<void> {
		try {
			const file = this.plugin.app.vault.getAbstractFileByPath(notePath);
			if (!file) {
				throw new Error(`Заметка не найдена: ${notePath}`);
			}

			const currentContent = await this.plugin.app.vault.read(file as any);
			
			// Создаем содержимое ответа
			const replyDate = timestampToDate(replyMessage.date);
			const replyDateStr = formatDateForNote(replyDate);
			const replyText = replyMessage.text || replyMessage.caption || '';
			
			let replyContent = `- **${replyDateStr}**\n`;
			if (replyText) {
				replyContent += `  ${replyText}\n`;
			}
			
			// Медиафайлы в ответе
			if (replyMediaFiles.length > 0) {
				for (const media of replyMediaFiles) {
					if (media.mimeType?.startsWith('image/')) {
						replyContent += `  ![[${media.filePath}]]\n`;
					} else {
						replyContent += `  [[${media.filePath}]]\n`;
					}
				}
			}
			
			// Информация об отправителе ответа
			if (replyMessage.from) {
				const fromInfo = replyMessage.from.username 
					? `@${replyMessage.from.username}`
					: replyMessage.from.first_name || 'Unknown';
				replyContent += `  *От: ${fromInfo}*\n`;
			}
			
			replyContent += '\n';

			// Проверяем, есть ли уже раздел "Ответы"
			if (currentContent.includes('**Ответы:**')) {
				// Находим позицию после "**Ответы:**" и добавляем ответ туда
				const repliesIndex = currentContent.indexOf('**Ответы:**');
				const afterReplies = currentContent.substring(repliesIndex + '**Ответы:**'.length);
				// Убираем лишние переносы строк в начале
				const cleanedAfter = afterReplies.replace(/^\s*\n+/, '');
				const newContent = currentContent.substring(0, repliesIndex + '**Ответы:**'.length) + '\n\n' + replyContent + cleanedAfter;
				await this.plugin.app.vault.modify(file as any, newContent);
			} else {
				// Добавляем раздел "Ответы"
				const newContent = currentContent.trim() + '\n\n---\n\n**Ответы:**\n\n' + replyContent;
				await this.plugin.app.vault.modify(file as any, newContent);
			}
		} catch (error) {
			console.error('Error adding reply to note:', error);
			throw error;
		}
	}
}

